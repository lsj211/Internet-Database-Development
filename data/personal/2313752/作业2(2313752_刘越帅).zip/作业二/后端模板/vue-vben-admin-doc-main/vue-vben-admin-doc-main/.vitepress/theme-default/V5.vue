<template>
  <div class="vben-v5">
    你正在查看的是 2.0 版本文档,当前最新版本为 v5.0，预览地址为
    <a href="https://vben.pro" target="_blank">预览地址</a>。 如果你想要查看新版本文档，请点击
    <a href="https://doc.vben.pro/" target="_blank"> V5 文档 </a> 查看最新文档。
  </div>
</template>

<style scoped>
  .vben-v5 {
    position: fixed;
    height: 60px;
    z-index: 1000;
    top: 0;
    left: 0;
    background: rgb(246, 197, 20);
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #333;
  }
</style>
