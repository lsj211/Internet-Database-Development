# 测试服务器

在项目 `/test/server` 内有简单的 Node.js 测试后台接口服务，用 Koa2 实现

## 使用

```bash

cd ./test/server

# 安装依赖
yarn

# 运行服务
yarn start

```

服务运行成功之后，就可以访问测试上传接口及 websocket 接口服务
