# 相关项目
对接vben的项目地址，非官方项目，vben用户开源，开源协议请自行查看

## golang
1. **后端**：https://github.com/vbenjs/gf-vben **前端**：https://github.com/vbenjs/gf-vben-admin

## php
1. **后端**：https://github.com/Joyboo/Joyboo-admin-easyswoole **前端**：https://github.com/Joyboo/Joyboo-vben-admin-thin
2. **后端**: https://github.com/wcz0/laravel-vben **前端**: https://github.com/wcz0/laravel-vben-admin

## java
1. **后端SpringCloud**：https://github.com/zuihou/lamp-cloud  **后端SpringBoot**：https://github.com/zuihou/lamp-boot   **前端**：https://github.com/zuihou/lamp-web-plus
2. **后端**：https://gitee.com/skysong/coffee-boot
3. **后端**：https://gitee.com/battcn/wemirr-platform **前端**：https://gitee.com/battcn/wemirr-platform-ui
4. **后端**：https://gitee.com/zsvg/vboot-java **前端**：https://gitee.com/zsvg/vboot-vben
5. **后端SpringBoot**：https://github.com/uncarbon97/helio-boot   **后端SpringCloud**：https://github.com/uncarbon97/helio-cloud   **前端**：https://github.com/uncarbon97/helio-admin-vue-vben
6. **后端SpringBoot**：https://gitee.com/zhijiantianya/ruoyi-vue-pro   **后端SpringCloud**：https://gitee.com/zhijiantianya/yudao-cloud   **前端**：https://gitee.com/yudaocode/yudao-ui-admin-vben

## .net
1. 对接Osharp **前端**：https://github.com/zionLZH/osharp-vben-admin 
2. **后端**：https://gitee.com/zsvg/vboot-net **前端**：https://gitee.com/zsvg/vboot-vben
3. Admin.NET **源码地址**：https://gitee.com/zuohuaijun/Admin.NET
