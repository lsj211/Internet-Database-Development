# vue-vben-admin-doc

## 如何本地开发

```bash
# 克隆本仓库
$ git clone git@github.com:vbenjs/vue-vben-admin-doc.git

# 或者使用 yarn
$ pnpm install

# 启动开发服务器
$ pnpm dev
```
