document.addEventListener('DOMContentLoaded', function() {
  // 等页面元素加载完，给“高亮”按钮绑点击事件
  const highlightBtn = document.getElementById('highlightBtn');
  highlightBtn.addEventListener('click', function() {
    const keyword = document.getElementById('keyword').value; // 获取输入的关键词
    // 向当前活跃的标签页注入脚本，执行“高亮”逻辑
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.scripting.executeScript({
        target: {tabId: tabs[0].id},
        function: highlightText, // 要注入的函数
        args: [keyword] // 传给函数的参数（关键词）
      });
    });
  });
});

// 注入到网页的“高亮逻辑”函数
function highlightText(keyword) {
  if (!keyword) return; // 关键词为空就不处理
  // 用正则表达式匹配所有关键词（不区分大小写）
  const regex = new RegExp(keyword, 'gi');
  // 替换页面内容，给匹配的文字加黄色背景
  document.body.innerHTML = document.body.innerHTML.replace(regex, function(match) {
    return `<span style="background-color: yellow;">${match}</span>`;
  });
}