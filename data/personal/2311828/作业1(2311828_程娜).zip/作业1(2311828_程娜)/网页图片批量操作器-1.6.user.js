// ==UserScript==
// @name         网页图片批量操作器
// @namespace    http://tampermonkey.net/
// @version      1.6
// @description  智能检测网页图片，批量下载、预览
// @author       doudoudadi
// @match        *://*/*
// @grant        GM_download
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_addStyle
// @grant        GM_notification
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    console.log('🖼️ 图片管理器插件已加载');

    // 确保页面完全加载后再初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initPlugin);
    } else {
        initPlugin();
    }

    function initPlugin() {
        setTimeout(() => {
            console.log('🚀 开始初始化图片管理器');
            createStyles();
            createInterface();
            setupEventListeners();
            detectImages();
        }, 1000);
    }

    // 全局变量
    let detectedImages = [];
    let selectedImages = [];
    let isVisible = false;
    let currentFilter = 'all';

    // 添加样式
    function createStyles() {
        GM_addStyle(`
            #img-manager-toggle {
                position: fixed !important;
                top: 20px !important;
                right: 20px !important;
                width: 60px !important;
                height: 60px !important;
                background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%) !important;
                color: white !important;
                border: none !important;
                border-radius: 50% !important;
                cursor: pointer !important;
                font-size: 20px !important;
                z-index: 2147483647 !important;
                box-shadow: 0 4px 20px rgba(255, 107, 107, 0.4) !important;
                transition: all 0.3s ease !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                font-family: Arial, sans-serif !important;
                flex-direction: column !important;
                line-height: 1 !important;
            }

            #img-manager-toggle:hover {
                transform: scale(1.1) !important;
                box-shadow: 0 6px 25px rgba(255, 107, 107, 0.6) !important;
            }

            #img-manager-panel {
                position: fixed !important;
                top: 20px !important;
                right: 90px !important;
                width: 380px !important;
                height: calc(100vh - 40px) !important;
                max-height: 700px !important;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
                color: white !important;
                border-radius: 15px !important;
                padding: 0 !important;
                box-shadow: 0 10px 40px rgba(0,0,0,0.3) !important;
                z-index: 2147483646 !important;
                font-family: Arial, sans-serif !important;
                display: none !important;
                backdrop-filter: blur(10px) !important;
                overflow: hidden !important;
            }

            #img-manager-panel.show {
                display: flex !important;
                flex-direction: column !important;
            }

            .img-header {
                text-align: center !important;
                padding: 20px 20px 15px 20px !important;
                border-bottom: 1px solid rgba(255,255,255,0.3) !important;
                flex-shrink: 0 !important;
            }

            .img-title {
                font-size: 16px !important;
                font-weight: bold !important;
                margin: 0 !important;
                color: white !important;
            }

            .img-content {
                flex: 1 !important;
                display: flex !important;
                flex-direction: column !important;
                padding: 0 20px 20px 20px !important;
                overflow: hidden !important;
            }

            .img-stats {
                display: grid !important;
                grid-template-columns: 1fr 1fr 1fr !important;
                gap: 8px !important;
                margin: 15px 0 !important;
                flex-shrink: 0 !important;
            }

            .stat-box {
                text-align: center !important;
                padding: 8px !important;
                background: rgba(255,255,255,0.2) !important;
                border-radius: 8px !important;
                font-size: 11px !important;
            }

            .stat-number {
                font-size: 16px !important;
                font-weight: bold !important;
                display: block !important;
                margin-bottom: 2px !important;
            }

            .img-controls {
                display: grid !important;
                grid-template-columns: 1fr 1fr !important;
                gap: 8px !important;
                margin-bottom: 15px !important;
                flex-shrink: 0 !important;
            }

            .img-btn {
                padding: 8px 10px !important;
                background: rgba(255,255,255,0.2) !important;
                color: white !important;
                border: 1px solid rgba(255,255,255,0.3) !important;
                border-radius: 8px !important;
                cursor: pointer !important;
                font-size: 11px !important;
                font-weight: bold !important;
                transition: all 0.2s ease !important;
                text-align: center !important;
            }

            .img-btn:hover {
                background: rgba(255,255,255,0.3) !important;
                transform: translateY(-1px) !important;
            }

            .img-btn.primary {
                background: linear-gradient(135deg, #28a745 0%, #20c997 100%) !important;
                border: none !important;
            }

            .filter-section {
                margin-bottom: 15px !important;
                flex-shrink: 0 !important;
            }

            .filter-title {
                font-size: 12px !important;
                font-weight: bold !important;
                margin-bottom: 8px !important;
                opacity: 0.9 !important;
                display: flex !important;
                align-items: center !important;
                gap: 5px !important;
            }

            .filter-options {
                display: flex !important;
                flex-wrap: wrap !important;
                gap: 5px !important;
            }

            .filter-tag {
                padding: 4px 8px !important;
                background: rgba(255,255,255,0.2) !important;
                border: 1px solid rgba(255,255,255,0.3) !important;
                border-radius: 12px !important;
                cursor: pointer !important;
                font-size: 10px !important;
                transition: all 0.2s ease !important;
                white-space: nowrap !important;
            }

            .filter-tag.active {
                background: #ffd700 !important;
                color: #333 !important;
                border-color: #ffd700 !important;
                font-weight: bold !important;
            }

            .filter-tag:hover {
                background: rgba(255,255,255,0.3) !important;
            }

            .img-list-container {
                flex: 1 !important;
                display: flex !important;
                flex-direction: column !important;
                min-height: 0 !important;
            }

            .img-list {
                flex: 1 !important;
                overflow-y: auto !important;
                overflow-x: hidden !important;
                padding-right: 5px !important;
                margin-right: -5px !important;
            }

            .img-list::-webkit-scrollbar {
                width: 6px !important;
            }

            .img-list::-webkit-scrollbar-track {
                background: rgba(255,255,255,0.1) !important;
                border-radius: 3px !important;
            }

            .img-list::-webkit-scrollbar-thumb {
                background: rgba(255,255,255,0.4) !important;
                border-radius: 3px !important;
            }

            .img-list::-webkit-scrollbar-thumb:hover {
                background: rgba(255,255,255,0.6) !important;
            }

            .img-item {
                display: flex !important;
                align-items: center !important;
                padding: 10px !important;
                margin: 0 0 8px 0 !important;
                background: rgba(255,255,255,0.1) !important;
                border-radius: 10px !important;
                cursor: pointer !important;
                transition: all 0.2s ease !important;
                border: 2px solid transparent !important;
            }

            .img-item:hover {
                background: rgba(255,255,255,0.2) !important;
                transform: translateX(3px) !important;
            }

            .img-item.selected {
                background: rgba(255, 215, 0, 0.3) !important;
                border-color: #ffd700 !important;
            }

            .img-checkbox {
                margin-right: 10px !important;
                transform: scale(1.1) !important;
                pointer-events: auto !important;
            }

            .img-preview {
                width: 50px !important;
                height: 50px !important;
                object-fit: cover !important;
                border-radius: 6px !important;
                margin-right: 10px !important;
                border: 1px solid rgba(255,255,255,0.3) !important;
                flex-shrink: 0 !important;
            }

            .img-info {
                flex: 1 !important;
                font-size: 11px !important;
                line-height: 1.3 !important;
                min-width: 0 !important;
            }

            .img-name {
                font-weight: bold !important;
                margin-bottom: 3px !important;
                word-break: break-all !important;
                overflow: hidden !important;
                display: -webkit-box !important;
                -webkit-line-clamp: 2 !important;
                -webkit-box-orient: vertical !important;
            }

            .img-details {
                opacity: 0.8 !important;
                font-size: 10px !important;
                display: flex !important;
                gap: 8px !important;
                align-items: center !important;
            }

            .format-badge {
                background: rgba(255,255,255,0.3) !important;
                padding: 1px 6px !important;
                border-radius: 8px !important;
                font-size: 9px !important;
                font-weight: bold !important;
            }

            .img-actions {
                display: flex !important;
                gap: 5px !important;
                flex-shrink: 0 !important;
            }

            .action-btn {
                width: 28px !important;
                height: 28px !important;
                background: rgba(255,255,255,0.2) !important;
                border: none !important;
                border-radius: 50% !important;
                color: white !important;
                cursor: pointer !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                font-size: 12px !important;
                transition: all 0.2s ease !important;
                pointer-events: auto !important;
            }

            .action-btn:hover {
                background: rgba(255,255,255,0.4) !important;
                transform: scale(1.1) !important;
            }

            .empty-state {
                text-align: center !important;
                padding: 40px 20px !important;
                opacity: 0.7 !important;
                font-size: 12px !important;
                line-height: 1.5 !important;
            }
        `);
        console.log('✅ 样式已添加');
    }

    // 创建界面
    function createInterface() {
        // 创建切换按钮
        const toggle = document.createElement('button');
        toggle.id = 'img-manager-toggle';
        toggle.innerHTML = '🖼️';
        toggle.title = '图片批量管理器';

        // 创建面板
        const panel = document.createElement('div');
        panel.id = 'img-manager-panel';
        panel.innerHTML = `
            <div class="img-header">
                <div class="img-title">🖼️ 图片批量管理器</div>
            </div>

            <div class="img-content">
                <div class="img-stats">
                    <div class="stat-box">
                        <span class="stat-number" id="total-count">0</span>
                        <span>检测图片</span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-number" id="selected-count">0</span>
                        <span>已选择</span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-number" id="size-count">0KB</span>
                        <span>总大小</span>
                    </div>
                </div>

                <div class="img-controls">
                    <button class="img-btn primary" id="download-btn">📥 下载选中</button>
                    <button class="img-btn" id="select-all-btn">✅ 全选</button>
                    <button class="img-btn" id="refresh-btn">🔄 重新检测</button>
                    <button class="img-btn" id="preview-btn">👁️ 批量预览</button>
                </div>

                <div class="filter-section">
                    <div class="filter-title">📂 图片筛选</div>
                    <div class="filter-options">
                        <span class="filter-tag active" data-filter="all">全部</span>
                        <span class="filter-tag" data-filter="large">大尺寸</span>
                        <span class="filter-tag" data-filter="jpg">JPG</span>
                        <span class="filter-tag" data-filter="png">PNG</span>
                        <span class="filter-tag" data-filter="gif">GIF</span>
                        <span class="filter-tag" data-filter="svg">SVG</span>
                    </div>
                </div>

                <div class="img-list-container">
                    <div class="img-list" id="img-list">
                        <div class="empty-state">
                            🔍 正在检测页面图片...<br>
                            <small>请稍候片刻</small>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // 添加到页面
        document.body.appendChild(toggle);
        document.body.appendChild(panel);

        console.log('✅ 界面已创建');
    }

    // 设置事件监听
    function setupEventListeners() {
        console.log('🔧 设置事件监听器...');

        // 主按钮点击事件
        document.addEventListener('click', function(e) {
            // 切换按钮
            if (e.target.id === 'img-manager-toggle') {
                e.preventDefault();
                e.stopPropagation();
                togglePanel();
                return;
            }

            // 下载选中按钮
            if (e.target.id === 'download-btn') {
                e.preventDefault();
                e.stopPropagation();
                downloadSelected();
                return;
            }

            // 全选按钮
            if (e.target.id === 'select-all-btn') {
                e.preventDefault();
                e.stopPropagation();
                selectAll();
                return;
            }

            // 刷新按钮
            if (e.target.id === 'refresh-btn') {
                e.preventDefault();
                e.stopPropagation();
                refreshImages();
                return;
            }

            // 批量预览按钮
            if (e.target.id === 'preview-btn') {
                e.preventDefault();
                e.stopPropagation();
                previewSelected();
                return;
            }

            // 筛选标签
            if (e.target.classList.contains('filter-tag')) {
                e.preventDefault();
                e.stopPropagation();
                const filter = e.target.getAttribute('data-filter');
                if (filter) {
                    setFilter(filter);
                }
                return;
            }

            // 图片项点击（选择/取消选择）
            if (e.target.classList.contains('img-item')) {
                e.preventDefault();
                e.stopPropagation();
                const imageId = e.target.getAttribute('data-image-id');
                if (imageId) {
                    toggleSelection(imageId);
                }
                return;
            }

            // 预览按钮
            if (e.target.classList.contains('action-btn') &&
                (e.target.textContent === '👁️' || e.target.title === '预览')) {
                e.preventDefault();
                e.stopPropagation();
                const imgItem = e.target.closest('.img-item');
                if (imgItem) {
                    const imageId = imgItem.getAttribute('data-image-id');
                    if (imageId) {
                        console.log('🔍 预览图片按钮点击:', imageId);
                        previewImage(imageId);
                    }
                }
                return;
            }

            // 下载按钮
            if (e.target.classList.contains('action-btn') &&
                (e.target.textContent === '📥' || e.target.title === '下载')) {
                e.preventDefault();
                e.stopPropagation();
                const imgItem = e.target.closest('.img-item');
                if (imgItem) {
                    const imageId = imgItem.getAttribute('data-image-id');
                    if (imageId) {
                        console.log('📥 下载图片按钮点击:', imageId);
                        downloadSingle(imageId);
                    }
                }
                return;
            }
        });

        // 复选框变化事件
        document.addEventListener('change', function(e) {
            if (e.target.classList.contains('img-checkbox')) {
                e.stopPropagation();
                const imgItem = e.target.closest('.img-item');
                if (imgItem) {
                    const imageId = imgItem.getAttribute('data-image-id');
                    if (imageId) {
                        console.log('☑️ 复选框变化:', imageId, e.target.checked);
                        toggleSelection(imageId);
                    }
                }
            }
        });

        console.log('✅ 事件监听已设置');
    }

    // 切换面板显示
    function togglePanel() {
        const panel = document.getElementById('img-manager-panel');
        isVisible = !isVisible;
        panel.classList.toggle('show', isVisible);
        if (isVisible) {
            updateDisplay();
        }
        console.log('🔄 面板切换:', isVisible ? '显示' : '隐藏');
    }

    // 刷新图片
    function refreshImages() {
        detectedImages = [];
        selectedImages = [];
        detectImages();
        console.log('🔄 刷新图片列表');
    }

    // 设置筛选器
    function setFilter(filter) {
        currentFilter = filter;

        // 更新筛选标签样式
        document.querySelectorAll('.filter-tag').forEach(tag => {
            tag.classList.remove('active');
        });
        const activeTag = document.querySelector(`[data-filter="${filter}"]`);
        if (activeTag) {
            activeTag.classList.add('active');
        }

        updateDisplay();
        console.log('🔍 切换筛选:', filter);
    }

    // 获取筛选后的图片
    function getFilteredImages() {
        return detectedImages.filter(img => {
            switch (currentFilter) {
                case 'large':
                    return img.width >= 500 && img.height >= 500;
                case 'jpg':
                    return getImageFormat(img.src) === 'jpg';
                case 'png':
                    return getImageFormat(img.src) === 'png';
                case 'gif':
                    return getImageFormat(img.src) === 'gif';
                case 'svg':
                    return getImageFormat(img.src) === 'svg';
                default:
                    return true;
            }
        });
    }

    // 获取图片格式
    function getImageFormat(src) {
        const url = src.toLowerCase();
        if (url.includes('.jpg') || url.includes('.jpeg')) return 'jpg';
        if (url.includes('.png')) return 'png';
        if (url.includes('.gif')) return 'gif';
        if (url.includes('.svg')) return 'svg';
        if (url.includes('.webp')) return 'webp';
        return 'other';
    }

    // 估算文件大小
    function estimateFileSize(width, height, format) {
        const pixels = width * height;
        let bytesPerPixel = 3;

        switch (format) {
            case 'jpg': bytesPerPixel = 1.5; break;
            case 'png': bytesPerPixel = 4; break;
            case 'gif': bytesPerPixel = 1; break;
            case 'svg': bytesPerPixel = 0.1; break;
            case 'webp': bytesPerPixel = 1.2; break;
        }

        return Math.round(pixels * bytesPerPixel);
    }

    // 格式化文件大小
    function formatFileSize(bytes) {
        if (bytes < 1024) return bytes + 'B';
        if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + 'KB';
        return Math.round(bytes / (1024 * 1024) * 10) / 10 + 'MB';
    }

    // 检测图片
    function detectImages() {
        console.log('🔍 开始检测图片...');

        const images = document.querySelectorAll('img');
        const newImages = [];

        images.forEach((img, index) => {
            if (img.src &&
                img.src.startsWith('http') &&
                !img.src.includes('data:') &&
                img.naturalWidth > 50 &&
                img.naturalHeight > 50) {

                const format = getImageFormat(img.src);
                const imageData = {
                    id: `img_${Date.now()}_${index}`,
                    src: img.src,
                    alt: img.alt || `图片${index + 1}`,
                    width: img.naturalWidth || img.width || 0,
                    height: img.naturalHeight || img.height || 0,
                    format: format,
                    size: estimateFileSize(img.naturalWidth || img.width || 0, img.naturalHeight || img.height || 0, format),
                    element: img
                };

                // 检查是否已存在
                if (!detectedImages.find(existing => existing.src === imageData.src)) {
                    newImages.push(imageData);
                }
            }
        });

        detectedImages = [...detectedImages, ...newImages];

        // 去重
        detectedImages = detectedImages.filter((img, index, self) =>
            index === self.findIndex(t => t.src === img.src)
        );

        console.log(`✅ 检测完成，找到 ${detectedImages.length} 张图片`);

        if (isVisible) {
            updateDisplay();
        }

        // 更新按钮显示检测到的图片数量
        const toggle = document.getElementById('img-manager-toggle');
        if (toggle && detectedImages.length > 0) {
            toggle.innerHTML = `🖼️<br><span style="font-size:10px;">${detectedImages.length}</span>`;
        }

        if (newImages.length > 0) {
            showNotification(`🖼️ 检测到 ${newImages.length} 张新图片`);
        }
    }

    // 更新显示
    function updateDisplay() {
        const filteredImages = getFilteredImages();

        // 更新统计
        document.getElementById('total-count').textContent = filteredImages.length;
        document.getElementById('selected-count').textContent = selectedImages.length;

        const totalSize = filteredImages.reduce((sum, img) => sum + img.size, 0);
        document.getElementById('size-count').textContent = formatFileSize(totalSize);

        // 🔧 更新全选按钮文本 - 根据当前状态显示正确的文本
        const selectAllBtn = document.getElementById('select-all-btn');
        if (selectAllBtn) {
            const filteredSelectedCount = getSelectedInCurrentFilter();
            if (filteredSelectedCount === 0) {
                selectAllBtn.textContent = '✅ 全选';
            } else if (filteredSelectedCount === filteredImages.length) {
                selectAllBtn.textContent = '❌ 取消全选';
            } else {
                selectAllBtn.textContent = `✅ 全选 (${filteredSelectedCount}/${filteredImages.length})`;
            }
        }

        // 更新图片列表
        const listElement = document.getElementById('img-list');
        if (filteredImages.length === 0) {
            listElement.innerHTML = `
                <div class="empty-state">
                    ${currentFilter === 'all' ?
                        '🔍 未检测到符合条件的图片<br><small>尝试刷新页面或滚动加载更多内容</small>' :
                        `📂 没有符合"${getFilterName(currentFilter)}"条件的图片<br><small>试试其他筛选条件</small>`
                    }
                </div>
            `;
        } else {
            listElement.innerHTML = filteredImages.map(img => `
                <div class="img-item ${selectedImages.includes(img.id) ? 'selected' : ''}"
                     data-image-id="${img.id}">
                    <input type="checkbox" class="img-checkbox"
                           ${selectedImages.includes(img.id) ? 'checked' : ''}>
                    <img class="img-preview" src="${img.src}"
                         onerror="this.style.display='none'">
                    <div class="img-info">
                        <div class="img-name">${img.alt}</div>
                        <div class="img-details">
                            <span>${img.width} × ${img.height}</span>
                            <span class="format-badge">${img.format.toUpperCase()}</span>
                            <span>${formatFileSize(img.size)}</span>
                        </div>
                    </div>
                    <div class="img-actions">
                        <button class="action-btn" title="预览">👁️</button>
                        <button class="action-btn" title="下载">📥</button>
                    </div>
                </div>
            `).join('');
        }

        console.log(`📊 显示更新: ${filteredImages.length} 张图片, ${selectedImages.length} 张已选择`);
    }

    // 🔧 获取当前筛选条件下已选择的图片数量
    function getSelectedInCurrentFilter() {
        const filteredImages = getFilteredImages();
        const filteredImageIds = filteredImages.map(img => img.id);
        return selectedImages.filter(id => filteredImageIds.includes(id)).length;
    }

    // 获取筛选器名称
    function getFilterName(filter) {
        const names = {
            'all': '全部',
            'large': '大尺寸',
            'jpg': 'JPG格式',
            'png': 'PNG格式',
            'gif': 'GIF格式',
            'svg': 'SVG格式'
        };
        return names[filter] || filter;
    }

    // 切换选择状态
    function toggleSelection(imageId) {
        const index = selectedImages.indexOf(imageId);
        if (index > -1) {
            selectedImages.splice(index, 1);
            console.log('❌ 取消选择:', imageId);
        } else {
            selectedImages.push(imageId);
            console.log('✅ 选择图片:', imageId);
        }
        updateDisplay();
    }

    // 全选/取消全选功能
    function selectAll() {
        const filteredImages = getFilteredImages();
        const filteredImageIds = filteredImages.map(img => img.id);
        const filteredSelectedCount = getSelectedInCurrentFilter();

        console.log('🔄 全选/取消全选操作:');
        console.log('  - 当前筛选图片数量:', filteredImages.length);
        console.log('  - 当前筛选下已选择数量:', filteredSelectedCount);
        console.log('  - 总选择数量:', selectedImages.length);

        if (filteredSelectedCount === filteredImages.length && filteredImages.length > 0) {
            // 如果当前筛选下的所有图片都已选择，则取消选择这些图片
            selectedImages = selectedImages.filter(id => !filteredImageIds.includes(id));
            console.log('❌ 取消全选当前筛选的图片');
        } else {
            // 否则选择当前筛选下的所有图片（保留其他筛选条件下已选择的图片）
            filteredImageIds.forEach(id => {
                if (!selectedImages.includes(id)) {
                    selectedImages.push(id);
                }
            });
            console.log('✅ 全选当前筛选的图片');
        }

        console.log('  - 操作后选择数量:', selectedImages.length);
        updateDisplay();
    }

    // 预览图片
    function previewImage(imageId) {
        const img = detectedImages.find(i => i.id === imageId);
        if (img) {
            console.log('🔍 预览图片:', img.alt, img.src);
            try {
                window.open(img.src, '_blank');
                showNotification(`👁️ 预览图片: ${img.alt}`);
            } catch (error) {
                console.error('❌ 预览失败:', error);
                createImageModal(img);
            }
        } else {
            console.error('❌ 找不到图片:', imageId);
        }
    }

    // 创建图片预览模态框
    function createImageModal(img) {
        const existingModal = document.getElementById('img-preview-modal');
        if (existingModal) {
            existingModal.remove();
        }

        const modal = document.createElement('div');
        modal.id = 'img-preview-modal';
        modal.style.cssText = `
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            width: 100% !important;
            height: 100% !important;
            background: rgba(0,0,0,0.9) !important;
            z-index: 2147483648 !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            cursor: pointer !important;
        `;

        modal.innerHTML = `
            <div style="max-width: 90%; max-height: 90%; text-align: center;">
                <img src="${img.src}" style="max-width: 100%; max-height: 100%; border-radius: 10px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
                <div style="color: white; margin-top: 15px; font-size: 14px; background: rgba(0,0,0,0.7); padding: 10px; border-radius: 5px;">
                    <strong>${img.alt}</strong><br>
                    ${img.width} × ${img.height} · ${img.format.toUpperCase()} · ${formatFileSize(img.size)}
                </div>
            </div>
        `;

        modal.addEventListener('click', () => modal.remove());
        document.body.appendChild(modal);
    }

    // 批量预览
    function previewSelected() {
        if (selectedImages.length === 0) {
            alert('请先选择要预览的图片');
            return;
        }

        const selectedImageData = detectedImages.filter(img => selectedImages.includes(img.id));
        console.log('👁️ 批量预览:', selectedImageData.length, '张图片');

        const previewWindow = window.open('', '_blank');

        if (!previewWindow) {
            alert('无法打开预览窗口，请允许弹窗或检查浏览器设置');
            return;
        }

        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>批量图片预览 - ${window.location.hostname}</title>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; margin: 0; }
                    .header { text-align: center; margin-bottom: 30px; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
                    .image-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
                    .image-card { background: white; border-radius: 10px; padding: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); transition: transform 0.2s ease; }
                    .image-card:hover { transform: translateY(-2px); }
                    .image-card img { width: 100%; height: 200px; object-fit: cover; border-radius: 5px; cursor: pointer; }
                    .image-info { margin-top: 10px; font-size: 12px; color: #666; }
                    .image-title { font-weight: bold; margin-bottom: 5px; color: #333; }
                    .download-link { display: inline-block; margin-top: 8px; padding: 4px 8px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; font-size: 11px; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>📸 图片批量预览</h1>
                    <p>共 ${selectedImageData.length} 张图片 - ${window.location.hostname}</p>
                </div>
                <div class="image-grid">
                    ${selectedImageData.map(img => `
                        <div class="image-card">
                            <img src="${img.src}" alt="${img.alt}" onclick="window.open(this.src, '_blank')">
                            <div class="image-info">
                                <div class="image-title">${img.alt}</div>
                                <div>尺寸: ${img.width} × ${img.height}</div>
                                <div>格式: ${img.format.toUpperCase()}</div>
                                <div>大小: ${formatFileSize(img.size)}</div>
                                <a href="${img.src}" download="${generateFileName(img)}" class="download-link">下载图片</a>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </body>
            </html>
        `;

        previewWindow.document.write(html);
        previewWindow.document.close();

        showNotification(`👁️ 已打开 ${selectedImageData.length} 张图片的预览窗口`);
    }

    // 下载选中图片
    function downloadSelected() {
        if (selectedImages.length === 0) {
            alert('请先选择要下载的图片');
            return;
        }

        const selectedImageData = detectedImages.filter(img => selectedImages.includes(img.id));
        console.log('📥 开始批量下载:', selectedImageData.length, '张图片');

        selectedImageData.forEach((img, index) => {
            setTimeout(() => {
                downloadImage(img);
            }, index * 300);
        });

        showNotification(`📥 开始下载 ${selectedImageData.length} 张图片`);
    }

    // 下载单张图片
    function downloadSingle(imageId) {
        const img = detectedImages.find(i => i.id === imageId);
        if (img) {
            console.log('📥 下载单张图片:', img.alt);
            downloadImage(img);
            showNotification(`📥 开始下载: ${img.alt}`);
        } else {
            console.error('❌ 找不到图片:', imageId);
        }
    }

    // 下载图片函数
    function downloadImage(img) {
        try {
            const fileName = generateFileName(img);

            if (typeof GM_download !== 'undefined') {
                GM_download(img.src, fileName, img.src);
                console.log('✅ GM_download 下载:', fileName);
            } else {
                const a = document.createElement('a');
                a.href = img.src;
                a.download = fileName;
                a.style.display = 'none';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                console.log('✅ 备用方法下载:', fileName);
            }
        } catch (error) {
            console.error('❌ 下载失败:', error);
            try {
                window.open(img.src, '_blank');
            } catch (e) {
                console.error('❌ 备用方案也失败:', e);
            }
        }
    }

    // 生成文件名
    function generateFileName(img) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
        const domain = window.location.hostname.replace(/[^a-zA-Z0-9]/g, '');
        const name = img.alt.replace(/[^a-zA-Z0-9\u4e00-\u9fa5]/g, '').substring(0, 20) || 'image';
        const extension = img.format === 'other' ? 'jpg' : img.format;

        return `${domain}_${name}_${timestamp}.${extension}`;
    }

    // 显示通知
    function showNotification(message) {
        console.log('📢 ' + message);
        if (typeof GM_notification !== 'undefined') {
            GM_notification(message, '图片管理器', { timeout: 3000 });
        }
    }

    // 定期检测新图片
    setInterval(detectImages, 5000);

    console.log('🎉 图片管理器插件初始化完成！');

})();